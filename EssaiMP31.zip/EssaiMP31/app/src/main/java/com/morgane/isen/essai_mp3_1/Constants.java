package com.morgane.isen.essai_mp3_1;

public class Constants {
    public class Audio {
        public static final String EXTRA_NAME = "extraName";
        public static final String EXTRA_ARTIST = "extraArtist";
        public static final String EXTRA_ALBUM = "extraAlbum";
        public static final String EXTRA_PATH = "extraPath";

    }
}
