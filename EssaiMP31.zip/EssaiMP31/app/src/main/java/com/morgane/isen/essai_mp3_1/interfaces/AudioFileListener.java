package com.morgane.isen.essai_mp3_1.interfaces;

import com.morgane.isen.essai_mp3_1.pojo.AudioFile;

public interface AudioFileListener {
    public void onViewAudio (AudioFile audioFile);
}
